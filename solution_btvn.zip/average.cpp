#include<bits/stdc++.h>
#define fi first
#define se second
#define sz(x) (int) (x).size()
#define TASK ""

using namespace std;

using lli = long long int;
using pii = pair<int,int>;
using ld = long double;

const int N = 1e5 + 5;

int n;
long long k;
int a[N];
lli s[N];

void input () {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) cin >> a[i];
}

bool check (ld M) {
    ld mi = 100000000000000000;
    int j = 0;
    for (int i = 1; i <= n; i++) {
        if (s[i] >= k) {
            while (j < i and s[i] - s[j] >= k) {
                mi = min(mi, s[j] - 1.0 * M * j);
                j++;
            }
            ld val = s[i] - 1.0 * M * i;
            if (val >= mi) return true;
        }
    }
    return false;
}

void solve () {
    s[0] = 0;
    for (int i = 1; i <= n; i++) s[i] = s[i - 1] + a[i];

    ld L = 0.5, R = 200000000000000000.0, res = -1;
    for (int z = 1; z <= 80; z++) {
        ld M = (L + R) / 2;
        if (check(M)) {
            res = M;
            L = M;
        }
        else R = M;
    }
    cout << fixed << setprecision(4) << res;
}

int main () {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    if (fopen(TASK ".inp", "r")) {
        freopen(TASK ".inp", "r", stdin);
        freopen(TASK ".out", "w", stdout);
    }

    int t = 1;

    while (t--) {
        input();
        solve();
    }
    return 0;
}
