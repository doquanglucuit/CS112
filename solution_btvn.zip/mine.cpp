#include<bits/stdc++.h>

using namespace std;

int dx[] = {-2, -1, -1, -1, 0, 0, 0, 0, 0, 1, 1, 1, 2};
int dy[] = {0, -1, 0, 1, -2, -1, 0, 1, 2, -1, 0, 1, 0};

const int N = 20;

int m, n;
int a[N][N];
int ans[N][N];

void input () {
    cin >> m >> n;
    for (int i = 1; i <= m; i++) for (int j = 1; j <= n; j++)
        cin >> a[i][j];
}

void checkAnswer () {
    bool flag = true;
    for (int i = max(m - 1, 1); i <= m; i++) for (int j = 1; j <= n; j++)
        flag &= a[i][j] == 0;

    if (not flag) return ;

    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) cout << ans[i][j] << ' '; cout << '\n';
    }
    exit(0);
}

bool tryPutMiner (int x, int y, int val) {
    bool flag = true;
    for (int i = 0; i < 13; i++) {
        int u = x + dx[i];
        int v = y + dy[i];
        if (1 <= u and u <= m and 1 <= v and v <= n) {
            a[u][v] += val;
            flag &= a[u][v] >= 0;
        }
    }
    return flag;
}

bool checkValid (int i, int j) {
    bool flag = true;

    if (i - 2 >= 1)
        flag &= a[i - 2][j] == 0;

    if (i - 1 >= 1) {
        if (j - 1 >= 1)
            flag &= a[i - 1][j - 1] <= 1;
        flag &= a[i - 1][j] <= 2 - (j == n);
    }
    return flag;
}

void backTrack (int i, int j) {
    if (i == m + 1) {
        checkAnswer();
        return;
    }

    int nxt_i = i, nxt_j = j + 1; // next position for backtrack
    if (nxt_j == n + 1) {
        nxt_j = 1;
        nxt_i++;
    }

    if (tryPutMiner(i, j, -1)) {  // try put miner in (i, j)
        ans[i][j] = 1;  //
        if (checkValid(i, j)) //
            backTrack(nxt_i, nxt_j);
    }
    ans[i][j] = 0;
    tryPutMiner(i, j, 1); // unput miner in (i, j)
    if (checkValid(i, j)) //
        backTrack(nxt_i, nxt_j);
}

void solve () {
    backTrack(1, 1);
}

int main () {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    input();
    solve();
    return 0;
}
