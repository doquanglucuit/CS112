#include <bits/stdc++.h>
#define name "ARTFLOWER"
using namespace std;
int n,k;
int main()
{   ios_base::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    //freopen(name".INP", "r", stdin);
    //freopen(name".OUT", "w", stdout);
    cin >>n>>k;
    vector <int> a;
    vector <vector <int> > grap(n+5,vector <int> (k+1));
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=k;j++)
        {
            cin >>grap[i][j];
        }
    }
    vector <vector <long long> > dp(n+5,vector <long long>(k+5,-1e18));
    dp[0][0]=0;
    for(int i=1;i<=n;i++)
    {
        long long so=-1e18;
        for(int j=1;j<=k;j++)
        {
            if(j>=i)
            {
                so=max(so,dp[i-1][j-1]);
                dp[i][j]=so+grap[i][j];
            }
        }
    }
    long long kq=-1e18;
    for(int i=n;i<=k;i++)
    {
        kq=max(kq,dp[n][i]);
    }
    cout <<kq;
    return 0;
}