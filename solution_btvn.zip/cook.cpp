#include<bits/stdc++.h>
using namespace std;

#define int long long

const int LimN = 2e5 + 5;

int n, m, k;
int a[LimN], b[LimN];

signed main() {

    cin >> n >> m >> k;

    for (int i = 1; i <= n; i++) cin >> a[i];

    for (int i = 1; i <= m; i++) cin >> b[i];

    sort(a + 1, a + 1 + n);
    sort(b + 1, b + 1 + m);


    int j = 1, ans = 0;
    for (int i = 1; i <= n; i++) {
        while (j <= m && b[j] < a[i] && a[i] - b[j] > k) j++;
        // cout << a[i] << " " << b[j] << " " << j << endl;
        if (j > m) break;
        if (abs(a[i] - b[j]) <= k) {
            ans++;
            j++;
        }
    }

    cout << ans << endl;


}